class JetraError(Exception):
    pass